const API_BASE_URL=(process.env.EXPO_PUBLIC_API_URL||'http://localhost:4000').replace(/\/$/,'');
let getToken=async()=>null;
export function setTokenGetter(fn){getToken=fn;}
async function request(path,{method='GET',body,auth=true,formData=false}={}){
  const headers={}; if(!formData)headers['Content-Type']='application/json'; if(auth){const t=await getToken();if(t)headers.Authorization=`Bearer ${t}`;}
  const res=await fetch(`${API_BASE_URL}${path}`,{method,headers,body:formData?body:body?JSON.stringify(body):undefined}); const isJson=res.headers.get('content-type')?.includes('application/json'); const data=isJson?await res.json():null; if(!res.ok)throw new Error(data?.error||`Request failed (${res.status})`); return data;
}
export const api={
 signInWithGoogle:idToken=>request('/auth/google',{method:'POST',body:{idToken},auth:false}),
 logout:()=>request('/auth/logout',{method:'POST'}), getMe:()=>request('/users/me'), updateMe:u=>request('/users/me',{method:'PATCH',body:u}), deleteMe:()=>request('/users/me',{method:'DELETE'}), updateKeys:k=>request('/users/me/keys',{method:'PUT',body:k}),
 searchUsers:q=>request(`/chat/users/search?q=${encodeURIComponent(q)}`), contacts:()=>request('/chat/contacts'), addContact:userId=>request('/chat/contacts',{method:'POST',body:{userId}}), conversations:()=>request('/chat/conversations'), direct:userId=>request('/chat/conversations/direct',{method:'POST',body:{userId}}), group:(title,memberIds)=>request('/chat/conversations/group',{method:'POST',body:{title,memberIds}}), conversation:id=>request(`/chat/conversations/${id}`), messages:(id,before)=>request(`/chat/conversations/${id}/messages?limit=50${before?`&before=${encodeURIComponent(before)}`:''}`), sendMessage:(id,body)=>request(`/chat/conversations/${id}/messages`,{method:'POST',body}), read:id=>request(`/chat/messages/${id}/read`,{method:'POST'}), delivered:id=>request(`/chat/messages/${id}/delivered`,{method:'POST'}), pushToken:(token,platform)=>request('/chat/push-tokens',{method:'POST',body:{token,platform}}), upload:form=>request('/chat/attachments',{method:'POST',body:form,formData:true}), linkAttachment:(attachmentId,messageId)=>request(`/chat/attachments/${attachmentId}/link`,{method:'POST',body:{messageId}}), health:()=>request('/health',{auth:false})
};
export {API_BASE_URL};
