import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
export async function registerPushToken(){
  const perms=await Notifications.getPermissionsAsync(); let status=perms.status;
  if(status!=='granted'){const r=await Notifications.requestPermissionsAsync();status=r.status;}
  if(status!=='granted')return null;
  const token=(await Notifications.getExpoPushTokenAsync()).data; return {token,platform:Platform.OS};
}
