import * as Google from 'expo-auth-session/providers/google';
import * as WebBrowser from 'expo-web-browser';

WebBrowser.maybeCompleteAuthSession();

/**
 * Google sign-in via the OAuth browser flow (works in plain Expo Go).
 *
 * You need OAuth client IDs from Google Cloud Console > APIs & Services >
 * Credentials — create one "Web application" client (used here AND by the
 * backend to verify tokens) and, once you're ready for a real device build,
 * one "Android" client with your app's SHA-1 fingerprint attached.
 * Drop them into mobile/.env as EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID etc.
 *
 * This returns an id_token, which is what the backend's /auth/google
 * endpoint expects — not the access_token.
 */
export function useGoogleSignIn() {
  const [request, response, promptAsync] = Google.useAuthRequest({
    webClientId: process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID,
    androidClientId: process.env.EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID,
  });

  return { request, response, promptAsync };
}

export function getIdTokenFromResponse(response) {
  if (response?.type !== 'success') return null;
  return response.authentication?.idToken ?? response.params?.id_token ?? null;
}
