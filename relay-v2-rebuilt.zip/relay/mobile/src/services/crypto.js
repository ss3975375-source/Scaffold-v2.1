import nacl from 'tweetnacl';
import base64 from 'base64-js';
import { secureStorage } from './secureStorage';

const IDENTITY='relay_identity_key'; const SIGNING='relay_signing_key';
const b64=u8=>base64.fromByteArray(u8); const unb64=s=>base64.toByteArray(s);
const textBytes=t=>new TextEncoder().encode(t); const bytesText=b=>new TextDecoder().decode(b);

async function getOrCreate(key, factory){ const saved=await secureStorage.getItem(key); if(saved)return JSON.parse(saved); const kp=factory(); const obj={publicKey:b64(kp.publicKey),secretKey:b64(kp.secretKey)}; await secureStorage.setItem(key,JSON.stringify(obj)); return obj; }
export async function ensureIdentity(){ const identity=await getOrCreate(IDENTITY,nacl.box.keyPair); const signing=await getOrCreate(SIGNING,nacl.sign.keyPair); return {identity,signing}; }
export async function publicKeys(){const {identity,signing}=await ensureIdentity(); return {identityPublicKey:identity.publicKey,signingPublicKey:signing.publicKey};}
export async function encryptForRecipients(plaintext, recipients){
  const {signing}=await ensureIdentity(); const output=[]; const payload=textBytes(plaintext);
  for(const r of recipients){
    const eph=nacl.box.keyPair(); const nonce=nacl.randomBytes(nacl.box.nonceLength); const cipher=nacl.box(payload,nonce,unb64(r.identityPublicKey),eph.secretKey);
    const signed=nacl.sign.detached(new Uint8Array([...eph.publicKey,...nonce,...cipher]),unb64(signing.secretKey));
    output.push({recipientId:r.id,ephemeralPublicKey:b64(eph.publicKey),nonce:b64(nonce),ciphertext:b64(cipher),signature:b64(signed),senderSigningPublicKey:signing.publicKey});
  }
  return output;
}
export async function decryptEnvelope(env){
  const {identity}=await ensureIdentity(); const body=new Uint8Array([...unb64(env.ephemeralPublicKey),...unb64(env.nonce),...unb64(env.ciphertext)]); if(!nacl.sign.detached.verify(body,unb64(env.signature),unb64(env.senderSigningPublicKey))) throw new Error('Message signature verification failed'); const plain=nacl.box.open(unb64(env.ciphertext),unb64(env.nonce),unb64(env.ephemeralPublicKey),unb64(identity.secretKey)); if(!plain) throw new Error('Unable to decrypt message'); return bytesText(plain);
}
export async function clearKeys(){ await secureStorage.removeItem(IDENTITY); await secureStorage.removeItem(SIGNING); }
export async function encryptFileBase64(base64Plain){
  const key=nacl.randomBytes(nacl.secretbox.keyLength); const nonce=nacl.randomBytes(nacl.secretbox.nonceLength); const cipher=nacl.secretbox(unb64(base64Plain),nonce,key); return {ciphertextBase64:b64(cipher),keyBase64:b64(key),nonceBase64:b64(nonce)};
}
export function decryptFileBase64(ciphertextBase64,keyBase64,nonceBase64){const plain=nacl.secretbox.open(unb64(ciphertextBase64),unb64(nonceBase64),unb64(keyBase64));if(!plain)throw new Error('Unable to decrypt attachment');return b64(plain);}
