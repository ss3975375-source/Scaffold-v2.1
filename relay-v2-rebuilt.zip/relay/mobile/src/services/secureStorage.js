import * as SecureStore from 'expo-secure-store';
const SESSION_TOKEN_KEY='session_token';
export const secureStorage={
  getToken:()=>SecureStore.getItemAsync(SESSION_TOKEN_KEY),
  setToken:t=>SecureStore.setItemAsync(SESSION_TOKEN_KEY,t),
  clearToken:()=>SecureStore.deleteItemAsync(SESSION_TOKEN_KEY),
  getItem:key=>SecureStore.getItemAsync(key),
  setItem:(key,value)=>SecureStore.setItemAsync(key,value),
  removeItem:key=>SecureStore.deleteItemAsync(key),
};
