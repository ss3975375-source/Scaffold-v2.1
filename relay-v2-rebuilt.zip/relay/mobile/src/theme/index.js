// Design direction: "sealed line" — the visual language of a private channel.
// Deep graphite-ink base, warm (not stark) text, and a single restrained
// signal color (a muted seal-gold) used only for things that matter:
// encryption status, unread badges, the primary action.
// Change these values any time — the rest of the app reads from here,
// so a rebrand later is a one-file edit, not a find-and-replace.

export const colors = {
  ink: '#13151B',        // app background
  surface: '#1C1F27',    // cards, your own message bubbles
  surfaceAlt: '#20242E', // received message bubbles
  border: '#2A2E38',

  textPrimary: '#F0EFEA',
  textMuted: '#8B8F9C',
  textOnAccent: '#13151B',

  accent: '#C9A15A',      // the one signature color — spend it deliberately
  accentMuted: '#3A331F', // accent's dark-surface tint, for subtle backgrounds

  success: '#6B9080',      // delivered / read / online
  danger: '#A8452F',       // destructive actions only
};

export const typography = {
  display: 'SpaceGrotesk_600SemiBold', // app name, screen titles — precise, technical
  displayBold: 'SpaceGrotesk_700Bold',
  body: 'Inter_400Regular',            // message text, inputs, everyday copy
  bodyMedium: 'Inter_500Medium',
  bodySemiBold: 'Inter_600SemiBold',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const radii = {
  sm: 8,
  md: 14,
  lg: 20,
  pill: 999,
};
