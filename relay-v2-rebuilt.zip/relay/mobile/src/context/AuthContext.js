import { createContext,useContext,useEffect,useState,useCallback } from 'react';
import { api,setTokenGetter } from '../services/api';
import { secureStorage } from '../services/secureStorage';
import { publicKeys,clearKeys } from '../services/crypto';
import { connectSocket,disconnectSocket } from '../services/socket';
import { registerPushToken } from '../services/notifications';
const AuthContext=createContext(null);
export function AuthProvider({children}){
 const [user,setUser]=useState(null); const [isLoading,setIsLoading]=useState(true);
 useEffect(()=>{setTokenGetter(()=>secureStorage.getToken());},[]);
 const finishAuth=useCallback(async(me,token)=>{await secureStorage.setToken(token); try{const keys=await publicKeys(); const updated=await api.updateKeys(keys); me=updated;}catch(e){console.warn('key registration failed',e.message);} setUser(me); const s=connectSocket(token); s?.on('conversation:added',({conversationId})=>s.emit('conversation:join',conversationId)); try{const push=await registerPushToken(); if(push) await api.pushToken(push.token,push.platform);}catch(e){console.warn('push registration failed',e.message);}},[]);
 useEffect(()=>{(async()=>{const token=await secureStorage.getToken(); if(!token){setIsLoading(false);return;} try{const me=await api.getMe(); if(!me.identityPublicKey){const keys=await publicKeys(); await api.updateKeys(keys);} setUser(me);const s=connectSocket(token); s?.on('conversation:added',({conversationId})=>s.emit('conversation:join',conversationId)); try{const push=await registerPushToken(); if(push) await api.pushToken(push.token,push.platform);}catch(e){console.warn('push registration failed',e.message);}}catch{await secureStorage.clearToken();}finally{setIsLoading(false);}})(); return ()=>disconnectSocket();},[]);
 const signInWithGoogleIdToken=useCallback(async(idToken)=>{const {token,user:signed}=await api.signInWithGoogle(idToken); await finishAuth(signed,token);return signed;},[finishAuth]);
 const signOut=useCallback(async()=>{try{await api.logout();}catch{} disconnectSocket();await secureStorage.clearToken();setUser(null);},[]);
 const deleteAccount=useCallback(async()=>{await api.deleteMe();disconnectSocket();await secureStorage.clearToken();await clearKeys();setUser(null);},[]);
 const refresh=useCallback(async()=>{const me=await api.getMe();setUser(me);return me;},[]);
 return <AuthContext.Provider value={{user,isLoading,signInWithGoogleIdToken,signOut,deleteAccount,refresh}}>{children}</AuthContext.Provider>;
}
export function useAuth(){const c=useContext(AuthContext);if(!c)throw new Error('useAuth must be used inside AuthProvider');return c;}
