import { useEffect, useState } from 'react';
import { View, Text, Pressable, StyleSheet, ActivityIndicator, Alert, Linking } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, typography, spacing, radii } from '../theme';
import { useGoogleSignIn, getIdTokenFromResponse } from '../services/googleAuth';
import { useAuth } from '../context/AuthContext';
import { API_BASE_URL } from '../services/api';

export default function SignInScreen() {
  const { request, response, promptAsync } = useGoogleSignIn();
  const { signInWithGoogleIdToken } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (response?.type !== 'success') return;

    const idToken = getIdTokenFromResponse(response);
    if (!idToken) {
      Alert.alert('Sign-in failed', 'No credential came back from Google. Try again.');
      return;
    }

    setIsSubmitting(true);
    signInWithGoogleIdToken(idToken)
      .catch((err) => Alert.alert('Sign-in failed', err.message))
      .finally(() => setIsSubmitting(false));
  }, [response]);

  const busy = isSubmitting || !request;

  return (
    <SafeAreaView style={styles.screen}>
      <View style={styles.content}>
        {/* Signature element: a small drawn seal, standing in for "this line is closed." */}
        <View style={styles.seal}>
          <View style={styles.sealDash} />
        </View>

        <Text style={styles.appName}>Relay</Text>
        <Text style={styles.tagline}>Your line, sealed.</Text>

        <Text style={styles.description}>
          Messages are encrypted on your device before they are sent. Relay stores encrypted message envelopes, not plaintext message content.
        </Text>
      </View>

      <View style={styles.footer}>
        <Pressable
          style={({ pressed }) => [styles.button, pressed && styles.buttonPressed]}
          onPress={() => promptAsync()}
          disabled={busy}
        >
          {busy ? (
            <ActivityIndicator color={colors.textOnAccent} />
          ) : (
            <Text style={styles.buttonText}>Continue with Google</Text>
          )}
        </Pressable>

        <Text style={styles.finePrint}>
          By continuing, you agree to our <Text style={styles.link} onPress={() => Linking.openURL(`${API_BASE_URL}/terms`)}>Terms</Text> and <Text style={styles.link} onPress={() => Linking.openURL(`${API_BASE_URL}/privacy`)}>Privacy Policy</Text>.
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.ink,
    justifyContent: 'space-between',
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
  },
  seal: {
    width: 56,
    height: 56,
    borderRadius: radii.pill,
    borderWidth: 1.5,
    borderColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.lg,
  },
  sealDash: {
    width: 20,
    height: 2,
    backgroundColor: colors.accent,
    borderRadius: 1,
  },
  appName: {
    fontFamily: typography.displayBold,
    fontSize: 34,
    color: colors.textPrimary,
    letterSpacing: 0.5,
  },
  tagline: {
    fontFamily: typography.body,
    fontSize: 15,
    color: colors.accent,
    marginTop: spacing.xs,
    marginBottom: spacing.lg,
  },
  description: {
    fontFamily: typography.body,
    fontSize: 15,
    lineHeight: 22,
    color: colors.textMuted,
    textAlign: 'center',
    maxWidth: 300,
  },
  footer: {
    paddingHorizontal: spacing.xl,
    paddingBottom: spacing.xl,
  },
  button: {
    backgroundColor: colors.accent,
    borderRadius: radii.md,
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonPressed: {
    opacity: 0.85,
  },
  buttonText: {
    fontFamily: typography.bodySemiBold,
    fontSize: 16,
    color: colors.textOnAccent,
  },
  link: { color: colors.accent },
  finePrint: {
    fontFamily: typography.body,
    fontSize: 12,
    color: colors.textMuted,
    textAlign: 'center',
    marginTop: spacing.md,
  },
});
