import { query } from '../config/db.js';

export async function findByGoogleId(googleId) {
  const { rows } = await query('SELECT * FROM users WHERE google_id=$1 AND deleted_at IS NULL', [googleId]);
  return rows[0] || null;
}
export async function findById(id) {
  const { rows } = await query('SELECT * FROM users WHERE id=$1 AND deleted_at IS NULL', [id]);
  return rows[0] || null;
}
export async function createFromGoogleProfile({ googleId, email, name, picture }) {
  const { rows } = await query(`INSERT INTO users (google_id,email,display_name,avatar_url) VALUES ($1,$2,$3,$4) RETURNING *`, [googleId,email,name,picture || null]);
  return rows[0];
}
export async function updateProfile(id, { displayName, avatarUrl }) {
  const { rows } = await query(`UPDATE users SET display_name=COALESCE($2,display_name), avatar_url=COALESCE($3,avatar_url) WHERE id=$1 AND deleted_at IS NULL RETURNING *`, [id,displayName ?? null,avatarUrl ?? null]);
  return rows[0] || null;
}
export async function updateKeys(id, { identityPublicKey, signingPublicKey }) {
  const { rows } = await query(`UPDATE users SET identity_public_key=$2, signing_public_key=$3 WHERE id=$1 AND deleted_at IS NULL RETURNING *`, [id, identityPublicKey, signingPublicKey]);
  return rows[0] || null;
}
export async function softDelete(id) {
  const client = await (await import('../config/db.js')).pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(`DELETE FROM push_tokens WHERE user_id=$1`, [id]);
    await client.query(`UPDATE users SET deleted_at=now(), email='deleted-'||id||'@deleted.local', display_name='Deleted user', avatar_url=NULL, identity_public_key=NULL, signing_public_key=NULL WHERE id=$1 AND deleted_at IS NULL`, [id]);
    await client.query('UPDATE sessions SET revoked_at=now() WHERE user_id=$1', [id]);
    await client.query('COMMIT');
    return true;
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
}
export function toPublicProfile(user) { return user ? { id:user.id,email:user.email,displayName:user.display_name,avatarUrl:user.avatar_url,identityPublicKey:user.identity_public_key,signingPublicKey:user.signing_public_key,createdAt:user.created_at } : null; }
