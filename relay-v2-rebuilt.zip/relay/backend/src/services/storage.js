import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import crypto from 'node:crypto';

const configured = process.env.S3_BUCKET && process.env.S3_ACCESS_KEY_ID && process.env.S3_SECRET_ACCESS_KEY;
const client = configured ? new S3Client({ region: process.env.S3_REGION || 'auto', endpoint: process.env.S3_ENDPOINT || undefined, forcePathStyle: !!process.env.S3_ENDPOINT, credentials: { accessKeyId: process.env.S3_ACCESS_KEY_ID, secretAccessKey: process.env.S3_SECRET_ACCESS_KEY } }) : null;
export function storageEnabled(){ return !!client; }
export function newObjectKey(userId, fileName){ return `${userId}/${crypto.randomUUID()}-${fileName.replace(/[^a-zA-Z0-9._-]/g,'_')}`; }
export async function putObject(key, buffer, mimeType){ if(!client) throw new Error('Attachment storage is not configured'); await client.send(new PutObjectCommand({Bucket:process.env.S3_BUCKET,Key:key,Body:buffer,ContentType:mimeType})); }
export async function getObject(key){ if(!client) throw new Error('Attachment storage is not configured'); return client.send(new GetObjectCommand({Bucket:process.env.S3_BUCKET,Key:key})); }
