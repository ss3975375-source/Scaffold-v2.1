import { query } from '../config/db.js';
export async function notifyUsers(userIds, title, body, data={}) {
  if (!userIds.length) return;
  const {rows}=await query('SELECT token FROM push_tokens WHERE user_id=ANY($1::uuid[])',[userIds]);
  if(!rows.length)return;
  const messages=rows.map(r=>({to:r.token,title,body,data,sound:'default'}));
  try { await fetch('https://exp.host/--/api/v2/push/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(messages)}); } catch(e){ console.error('push failed',e.message); }
}
