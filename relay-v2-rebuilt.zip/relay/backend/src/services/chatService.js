import { query, pool } from '../config/db.js';

export async function searchUsers(ownerId, term) {
  const { rows } = await query(`SELECT id,email,display_name,avatar_url,identity_public_key,signing_public_key FROM users WHERE deleted_at IS NULL AND id<>$1 AND (email ILIKE $2 OR display_name ILIKE $2) ORDER BY display_name LIMIT 30`, [ownerId, `%${term}%`]);
  return rows;
}

export async function addContact(ownerId, contactId) {
  if (ownerId === contactId) throw new Error('Cannot add yourself');
  await query(`INSERT INTO contacts(owner_id,contact_id,status) VALUES($1,$2,'accepted') ON CONFLICT(owner_id,contact_id) DO UPDATE SET status='accepted'`, [ownerId, contactId]);
  await query(`INSERT INTO contacts(owner_id,contact_id,status) VALUES($2,$1,'accepted') ON CONFLICT(owner_id,contact_id) DO UPDATE SET status='accepted'`, [ownerId, contactId]);
}

export async function listContacts(userId) {
  const { rows } = await query(`SELECT u.id,u.email,u.display_name,u.avatar_url,u.identity_public_key,u.signing_public_key,c.status FROM contacts c JOIN users u ON u.id=c.contact_id WHERE c.owner_id=$1 AND c.status='accepted' AND u.deleted_at IS NULL ORDER BY u.display_name`, [userId]);
  return rows;
}

export async function createDirectConversation(userId, otherUserId) {
  const { rows: existing } = await query(`SELECT c.id FROM conversations c JOIN conversation_members m1 ON m1.conversation_id=c.id AND m1.user_id=$1 JOIN conversation_members m2 ON m2.conversation_id=c.id AND m2.user_id=$2 WHERE c.kind='direct' AND m1.left_at IS NULL AND m2.left_at IS NULL LIMIT 1`, [userId, otherUserId]);
  if (existing[0]) return getConversation(userId, existing[0].id);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(`INSERT INTO conversations(kind,created_by) VALUES('direct',$1) RETURNING *`, [userId]);
    const id = rows[0].id;
    await client.query(`INSERT INTO conversation_members(conversation_id,user_id,role) VALUES($1,$2,'owner'),($1,$3,'member')`, [id,userId,otherUserId]);
    await client.query('COMMIT');
    return getConversation(userId, id);
  } catch(e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
}

export async function createGroup(userId, title, memberIds) {
  const ids = [...new Set([userId, ...memberIds])];
  if (ids.length < 2) throw new Error('A group needs at least two members');
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(`INSERT INTO conversations(kind,title,created_by) VALUES('group',$1,$2) RETURNING *`, [title,userId]);
    for (const memberId of ids) await client.query(`INSERT INTO conversation_members(conversation_id,user_id,role) VALUES($1,$2,$3)`, [rows[0].id,memberId,memberId===userId?'owner':'member']);
    await client.query('COMMIT');
    return getConversation(userId, rows[0].id);
  } catch(e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
}

export async function getConversation(userId, conversationId) {
  const { rows } = await query(`SELECT c.*, json_agg(json_build_object('id',u.id,'displayName',u.display_name,'email',u.email,'avatarUrl',u.avatar_url,'identityPublicKey',u.identity_public_key,'signingPublicKey',u.signing_public_key,'role',m.role) ORDER BY u.display_name) FILTER (WHERE u.id IS NOT NULL) AS members FROM conversations c JOIN conversation_members me ON me.conversation_id=c.id AND me.user_id=$1 AND me.left_at IS NULL LEFT JOIN conversation_members m ON m.conversation_id=c.id AND m.left_at IS NULL LEFT JOIN users u ON u.id=m.user_id WHERE c.id=$2 GROUP BY c.id`, [userId,conversationId]);
  return rows[0] || null;
}

export async function listConversations(userId) {
  const { rows } = await query(`SELECT c.id,c.kind,COALESCE(c.title,MAX(CASE WHEN cm.user_id<>$1 THEN u.display_name END)) AS title,c.avatar_url,c.updated_at,MAX(m.created_at) AS last_message_at,COUNT(DISTINCT cm.user_id)::int AS member_count FROM conversations c JOIN conversation_members me ON me.conversation_id=c.id AND me.user_id=$1 AND me.left_at IS NULL JOIN conversation_members cm ON cm.conversation_id=c.id AND cm.left_at IS NULL LEFT JOIN users u ON u.id=cm.user_id LEFT JOIN messages m ON m.conversation_id=c.id AND m.deleted_at IS NULL GROUP BY c.id ORDER BY COALESCE(MAX(m.created_at),c.updated_at) DESC`, [userId]);
  return rows;
}


export async function addGroupMembers(userId, conversationId, memberIds) {
  const {rows: admins}=await query(`SELECT role FROM conversation_members WHERE conversation_id=$1 AND user_id=$2 AND left_at IS NULL`,[conversationId,userId]);
  if(!['owner','admin'].includes(admins[0]?.role)) throw new Error('Admin permission required');
  for(const id of [...new Set(memberIds)]) await query(`INSERT INTO conversation_members(conversation_id,user_id,role) VALUES($1,$2,'member') ON CONFLICT(conversation_id,user_id) DO UPDATE SET left_at=NULL`,[conversationId,id]);
  return getConversation(userId,conversationId);
}
export async function removeGroupMember(userId, conversationId, memberId) {
  const {rows: admins}=await query(`SELECT role FROM conversation_members WHERE conversation_id=$1 AND user_id=$2 AND left_at IS NULL`,[conversationId,userId]);
  if(!['owner','admin'].includes(admins[0]?.role)) throw new Error('Admin permission required');
  await query(`UPDATE conversation_members SET left_at=now() WHERE conversation_id=$1 AND user_id=$2 AND user_id<>$3`,[conversationId,memberId,userId]);
}
export async function leaveConversation(userId, conversationId) { await query(`UPDATE conversation_members SET left_at=now() WHERE conversation_id=$1 AND user_id=$2 AND left_at IS NULL`,[conversationId,userId]); }

export async function getMembers(userId, conversationId) {
  const conv = await getConversation(userId, conversationId);
  return conv?.members || [];
}

export async function createMessage(userId, conversationId, clientMessageId, messageType, envelopes) {
  const membership = await getConversation(userId, conversationId);
  if (!membership) throw new Error('Conversation not found');
  const required = new Set((membership.members || []).map(m => m.id));
  const recipients = new Set(envelopes.map(e => e.recipientId));
  if (recipients.size !== required.size || [...required].some(id => !recipients.has(id))) throw new Error('Encrypted envelope set does not match conversation members');
  const sender = (membership.members || []).find(m => m.id === userId);
  if (!sender?.signingPublicKey || envelopes.some(e => e.senderSigningPublicKey !== sender.signingPublicKey)) throw new Error('Sender signing key mismatch');
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(`INSERT INTO messages(conversation_id,sender_id,client_message_id,message_type) VALUES($1,$2,$3,$4) RETURNING *`, [conversationId,userId,clientMessageId,messageType]);
    for (const e of envelopes) await client.query(`INSERT INTO message_envelopes(message_id,recipient_id,ephemeral_public_key,nonce,ciphertext,signature,sender_signing_public_key) VALUES($1,$2,$3,$4,$5,$6,$7)`, [rows[0].id,e.recipientId,e.ephemeralPublicKey,e.nonce,e.ciphertext,e.signature,e.senderSigningPublicKey]);
    await client.query(`INSERT INTO message_receipts(message_id,user_id,delivered_at) SELECT $1,user_id,CASE WHEN user_id=$2 THEN now() ELSE NULL END FROM conversation_members WHERE conversation_id=$3 AND left_at IS NULL ON CONFLICT DO NOTHING`, [rows[0].id,userId,conversationId]);
    await client.query(`UPDATE conversations SET updated_at=now() WHERE id=$1`, [conversationId]);
    await client.query('COMMIT');
    return getMessageForUser(userId, rows[0].id);
  } catch(e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
}

export async function getMessageForUser(userId, messageId) {
  const { rows } = await query(`SELECT m.id,m.conversation_id,m.sender_id,m.client_message_id,m.message_type,m.created_at,m.edited_at,m.deleted_at,e.recipient_id,e.ephemeral_public_key,e.nonce,e.ciphertext,e.signature,e.sender_signing_public_key, r.delivered_at,r.read_at FROM messages m JOIN message_envelopes e ON e.message_id=m.id AND e.recipient_id=$1 LEFT JOIN message_receipts r ON r.message_id=m.id AND r.user_id=$1 WHERE m.id=$2`, [userId,messageId]);
  return rows[0] || null;
}

export async function listMessages(userId, conversationId, limit=50, before=null) {
  const { rows } = await query(`SELECT m.id,m.conversation_id,m.sender_id,m.client_message_id,m.message_type,m.created_at,m.edited_at,m.deleted_at,e.recipient_id,e.ephemeral_public_key,e.nonce,e.ciphertext,e.signature,e.sender_signing_public_key,r.delivered_at,r.read_at FROM messages m JOIN conversation_members cm ON cm.conversation_id=m.conversation_id AND cm.user_id=$1 AND cm.left_at IS NULL JOIN message_envelopes e ON e.message_id=m.id AND e.recipient_id=$1 LEFT JOIN message_receipts r ON r.message_id=m.id AND r.user_id=$1 WHERE m.conversation_id=$2 AND m.deleted_at IS NULL AND ($3::timestamptz IS NULL OR m.created_at<$3) ORDER BY m.created_at DESC LIMIT $4`, [userId,conversationId,before,Math.min(limit,100)]);
  return rows.reverse();
}

export async function markRead(userId, messageId) {
  const { rows } = await query(`UPDATE message_receipts r SET delivered_at=COALESCE(delivered_at,now()), read_at=now() FROM messages m WHERE r.message_id=m.id AND r.user_id=$1 AND r.message_id=$2 RETURNING r.message_id,r.user_id,r.delivered_at,r.read_at,m.conversation_id`, [userId,messageId]);
  return rows[0] || null;
}

export async function markDelivered(userId, messageId) {
  const { rows } = await query(`UPDATE message_receipts r SET delivered_at=COALESCE(r.delivered_at,now()) FROM messages m WHERE r.message_id=m.id AND r.user_id=$1 AND r.message_id=$2 RETURNING r.*,m.conversation_id`, [userId,messageId]);
  return rows[0] || null;
}

export async function savePushToken(userId, token, platform) {
  await query(`INSERT INTO push_tokens(user_id,token,platform) VALUES($1,$2,$3) ON CONFLICT(user_id,token) DO UPDATE SET platform=EXCLUDED.platform`, [userId,token,platform]);
}


export async function attachToMessage(userId, messageId, attachmentId) {
  const { rows } = await query(`UPDATE attachments a SET message_id=$2 FROM messages m JOIN conversation_members cm ON cm.conversation_id=m.conversation_id AND cm.user_id=$1 WHERE a.id=$3 AND a.owner_id=$1 AND m.id=$2 RETURNING a.*`, [userId,messageId,attachmentId]);
  return rows[0] || null;
}
export async function getAttachmentForUser(userId, attachmentId) {
  const { rows } = await query(`SELECT a.* FROM attachments a JOIN messages m ON m.id=a.message_id JOIN conversation_members cm ON cm.conversation_id=m.conversation_id AND cm.user_id=$1 AND cm.left_at IS NULL WHERE a.id=$2`, [userId,attachmentId]);
  return rows[0] || null;
}

export async function addAttachmentMeta(userId, data) {
  const { rows } = await query(`INSERT INTO attachments(owner_id,object_key,file_name,mime_type,size_bytes) VALUES($1,$2,$3,$4,$5) RETURNING *`, [userId,data.objectKey,data.fileName,data.mimeType,data.sizeBytes]);
  return rows[0];
}
