import pg from 'pg';

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL is not set. Copy .env.example to .env and fill it in.');
}

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

pool.on('error', (err) => {
  // A background client crashed — log it, don't crash the whole server over one bad connection.
  console.error('Unexpected error on idle database client', err);
});

export async function query(text, params) {
  return pool.query(text, params);
}
