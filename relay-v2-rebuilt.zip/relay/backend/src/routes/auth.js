import { Router } from 'express';
import { verifyGoogleIdToken } from '../config/googleAuth.js';
import { findByGoogleId, createFromGoogleProfile, toPublicProfile } from '../models/userModel.js';
import { issueSessionToken, revokeToken, requireAuth } from '../middleware/auth.js';
import { z } from 'zod';
const router = Router();
const bodySchema = z.object({ idToken: z.string().min(20) });
router.post('/google', async (req,res)=>{
  const parsed=bodySchema.safeParse(req.body); if(!parsed.success) return res.status(400).json({error:'idToken is required'});
  try {
    const profile=await verifyGoogleIdToken(parsed.data.idToken); let user=await findByGoogleId(profile.googleId); let isNewUser=false;
    if(!user){ user=await createFromGoogleProfile(profile); isNewUser=true; }
    const token=await issueSessionToken(user);
    res.status(isNewUser?201:200).json({token,user:toPublicProfile(user),isNewUser});
  } catch(e){ console.error(e); res.status(401).json({error:'Sign-in failed'}); }
});
router.post('/logout', requireAuth, async (req,res)=>{ await revokeToken(req.user.token); res.status(204).send(); });
export default router;
