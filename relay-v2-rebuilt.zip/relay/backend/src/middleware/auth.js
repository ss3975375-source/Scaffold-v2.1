import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import { query } from '../config/db.js';

if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET is not set');

export function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export async function issueSessionToken(user) {
  const token = jwt.sign({ sub: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
  const decoded = jwt.decode(token);
  await query('INSERT INTO sessions (user_id, token_hash, expires_at) VALUES ($1,$2,to_timestamp($3))', [user.id, hashToken(token), decoded.exp]);
  return token;
}

export async function revokeToken(token) {
  await query('UPDATE sessions SET revoked_at=now() WHERE token_hash=$1', [hashToken(token)]);
}

export async function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing session token' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const { rows } = await query(`SELECT s.user_id, u.email FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at > now() AND u.deleted_at IS NULL`, [hashToken(token)]);
    if (!rows[0]) return res.status(401).json({ error: 'Session revoked or expired' });
    await query('UPDATE sessions SET last_seen_at=now() WHERE token_hash=$1', [hashToken(token)]);
    req.user = { id: decoded.sub, email: rows[0].email, token };
    next();
  } catch { return res.status(401).json({ error: 'Invalid or expired session token' }); }
}
