import jwt from 'jsonwebtoken';
import { getMessageForUser, markRead, markDelivered } from '../services/chatService.js';
import { query } from '../config/db.js';

export function attachSockets(io) {
  io.use((socket,next)=>{const token=socket.handshake.auth?.token; if(!token)return next(new Error('Missing session token')); try{const d=jwt.verify(token,process.env.JWT_SECRET); socket.userId=d.sub; next();}catch{next(new Error('Invalid session token'));}});
  io.on('connection',async socket=>{
    socket.join(`user:${socket.userId}`);
    const {rows}=await query(`SELECT conversation_id FROM conversation_members WHERE user_id=$1 AND left_at IS NULL`,[socket.userId]);
    for(const r of rows) socket.join(`conversation:${r.conversation_id}`);
    socket.broadcast.emit('presence',{userId:socket.userId,status:'online'});
    socket.on('conversation:join',conversationId=>{ if(typeof conversationId==='string') socket.join(`conversation:${conversationId}`); });
    socket.on('typing',({conversationId,isTyping})=>socket.to(`conversation:${conversationId}`).emit('typing',{conversationId,userId:socket.userId,isTyping:!!isTyping}));
    socket.on('message:delivered',async({messageId})=>{const r=await markDelivered(socket.userId,messageId); if(r) io.to(`conversation:${r.conversation_id||''}`).emit('message:receipt',{messageId,userId:socket.userId,deliveredAt:r.delivered_at});});
    socket.on('message:read',async({messageId})=>{const r=await markRead(socket.userId,messageId); if(r) io.to(`conversation:${r.conversation_id}`).emit('message:receipt',{messageId,userId:socket.userId,readAt:r.read_at,deliveredAt:r.delivered_at});});
    socket.on('message:send',async payload=>{try{const m=await getMessageForUser(socket.userId,payload.messageId); if(!m)return; io.to(`conversation:${m.conversation_id}`).emit('message:new',m);}catch(e){socket.emit('message:error',{error:e.message});}});
    socket.on('disconnect',()=>socket.broadcast.emit('presence',{userId:socket.userId,status:'offline'}));
  });
}
