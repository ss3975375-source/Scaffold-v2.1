import test from 'node:test';
import assert from 'node:assert/strict';
import { hashToken } from '../src/middleware/auth.js';

test('hashToken is deterministic and non-reversible-looking', () => {
  const a=hashToken('relay-test-token');
  assert.equal(a,hashToken('relay-test-token'));
  assert.match(a,/^[a-f0-9]{64}$/);
  assert.notEqual(a,'relay-test-token');
});
